#ifndef POLINOMIO_H
#define POLINOMIO_H

#include<string>
#include<list>
using namespace std;

class polinomio{
    private:
    list<Termi> polinomio;
    list<Termi>::iterator rep=polinomio.begin();
    public:
    polinomio(string& poli);
    string getstr(polinomio x);
};

#endif // POL_H

#endif // POLINOMIO_H
