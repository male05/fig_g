#include "polinomio.h".h"
#include "termino.h".h"
#include <string>
using namespace std;

polinomio::pol(string& polinomio)
{
   int x;
   stringstream te;
   for (x=0;x<polinomio.length();x++){
     if(polinomio[x]=='+'|| poli[x]=='-'){
     te<<poli[x+1]<<polinomio[x+2]<<polinomio[x+4];
     Termi y(te);
     polinomio.push_front(y);
     }
 }
}
string pol::getstr(polinomio x){
    stringstream te;
    int y;
    for (y=0;y<x.polinomio.size();y++)
     te<<'+'<< getstr(*(x.pos+y))<<endl;
    return te;
}
