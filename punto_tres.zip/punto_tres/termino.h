#ifndef TERMINO_H
#define TERMINO_H

#include <iostream>
#include <string>


using namespace std;

class Term {
  private:
    float  _co;
    int  _potencia;
    char _variable;

  public:
    Term(int p, float c,char v);
    Term(string& Te);
    string getstr(Term& T);
    float getC(){return _co;}
    int getP(){return _potencia;}
    char getV(){return _variable;}
    void setC(float& c){_co = c;}
    void setCP(float& c, int& p){_co = c; _potencia = p;}
    void setV(char& v){_variable=v;}
};

#endif // TERM_H

