#include "termino.h"

Term::Termino(int a,float b,char c){
    _coef = a;
    _pot = b;
    _var = c ;
}

string Term::getstr(Term& T) {
   stringstream te;
   te<<T._coef<<T._var<<'^'<<T._pot<<endl;
   return te.str();
}

Term::Termino(string& Te){
    _coef=atof(Te[0]);
    _var=Te[1];
    _pot=atoi(Te[3]);
}
