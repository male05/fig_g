#include <QCoreApplication>
//#include "term.h"
//#include "pol.h"
#include <iostream>
using namespace std;

int main()
{
        string a="+8x^5-3x^4+7x^6";
        pol polinomio(x);
        cout <<poli.getstr(polinomio)<< endl;
    return 0;
}
